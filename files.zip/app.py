#!/usr/bin/env python3
"""
app.py — Aplicación web para convertir recibos COBOL → PDF Decreto 407/2026
Ejecutar: python app.py
Abrir en navegador: http://localhost:5000
"""

import sys
# Bloquear matplotlib/numpy para evitar uso de memoria en Render free tier
for mod in list(sys.modules.keys()):
    if 'matplotlib' in mod or 'numpy' in mod:
        del sys.modules[mod]

from flask import Flask, request, send_file, render_template_string
import tempfile, os, sys

app = Flask(__name__)

HTML = """
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Recibos 407/2026 — Conversor</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', Arial, sans-serif; background: #F5F7FA; color: #212121; }
  header {
    background: linear-gradient(135deg, #1565C0, #0D47A1);
    color: white; padding: 22px 40px;
    display: flex; align-items: center; gap: 16px;
  }
  header h1 { font-size: 1.4rem; font-weight: 600; }
  header p  { font-size: 0.82rem; opacity: 0.85; margin-top: 3px; }
  .badge {
    background: #FFD600; color: #000; font-size: 0.7rem;
    font-weight: 700; padding: 3px 8px; border-radius: 12px; white-space: nowrap;
  }
  main { max-width: 680px; margin: 48px auto; padding: 0 20px; }
  .card {
    background: white; border-radius: 12px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.08); padding: 36px;
  }
  .card h2 { font-size: 1.05rem; color: #1565C0; margin-bottom: 6px; }
  .card p  { font-size: 0.88rem; color: #666; margin-bottom: 24px; line-height: 1.5; }
  .drop-zone {
    border: 2.5px dashed #90CAF9; border-radius: 10px;
    padding: 40px 20px; text-align: center; cursor: pointer;
    transition: all .2s; background: #F8FBFF; position: relative;
  }
  .drop-zone:hover, .drop-zone.dragover { border-color: #1565C0; background: #E3F2FD; }
  .drop-zone input[type=file] {
    position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%;
  }
  .drop-zone .icon { font-size: 2.8rem; margin-bottom: 10px; }
  .drop-zone .lbl  { font-size: 0.95rem; color: #1565C0; font-weight: 600; }
  .drop-zone .sub  { font-size: 0.8rem; color: #999; margin-top: 4px; }
  #filename { margin-top: 14px; font-size: 0.85rem; color: #388E3C; font-weight: 600; min-height: 20px; }
  .btn {
    display: block; width: 100%; margin-top: 24px;
    background: #1565C0; color: white; border: none;
    padding: 14px; border-radius: 8px; font-size: 1rem;
    font-weight: 600; cursor: pointer; transition: background .2s;
  }
  .btn:hover:not(:disabled) { background: #0D47A1; }
  .btn:disabled { background: #90A4AE; cursor: not-allowed; }
  #status {
    margin-top: 18px; padding: 14px 16px; border-radius: 8px;
    font-size: 0.88rem; display: none;
  }
  .status-ok    { background: #E8F5E9; color: #2E7D32; border: 1px solid #A5D6A7; }
  .status-err   { background: #FFEBEE; color: #B71C1C; border: 1px solid #EF9A9A; }
  .status-load  { background: #E3F2FD; color: #1565C0; border: 1px solid #90CAF9; }
  .spinner { display: inline-block; width: 14px; height: 14px;
    border: 2px solid #90CAF9; border-top-color: #1565C0;
    border-radius: 50%; animation: spin .7s linear infinite; vertical-align: middle; margin-right: 6px; }
  @keyframes spin { to { transform: rotate(360deg); } }
  .info-box {
    background: #FFF8E1; border: 1px solid #FFE082;
    border-radius: 8px; padding: 14px 16px; margin-top: 24px; font-size: 0.82rem; color: #5D4037;
  }
  .info-box strong { color: #E65100; }
  footer { text-align: center; margin-top: 36px; font-size: 0.75rem; color: #9E9E9E; }
</style>
</head>
<body>
<header>
  <div>
    <h1>📄 Conversor de Recibos</h1>
    <p>Ley 27.802 — Decreto 407/2026 — Anexo III</p>
  </div>
  <span class="badge">NEXSAT S.A.</span>
</header>

<main>
  <div class="card">
    <h2>Convertir TXT → PDF con gráfico de torta</h2>
    <p>Subí el archivo TXT generado por el sistema COBOL. Se generará un PDF
       con el formato oficial del Anexo III listo para subir a TuLegajo.</p>

    <form id="form" enctype="multipart/form-data">
      <div class="drop-zone" id="dropZone">
        <input type="file" name="txt_file" id="fileInput" accept=".txt,.TXT">
        <div class="icon">📂</div>
        <div class="lbl">Hacé clic o arrastrá el archivo TXT acá</div>
        <div class="sub">Archivos .TXT generados por COBOL</div>
      </div>
      <div id="filename"></div>
      <button class="btn" type="submit" id="btn" disabled>Generar PDF</button>
    </form>

    <div id="status"></div>

    <div class="info-box">
      <strong>¿Cómo usar?</strong><br>
      1. Seleccioná el TXT de la liquidación<br>
      2. Hacé clic en <em>Generar PDF</em><br>
      3. Se descarga el PDF automáticamente<br>
      4. Subilo a <strong>TuLegajo.com</strong> — ya incluye el gráfico de torta oficial
    </div>
  </div>
  <footer>Recibos generados conforme Ley 27.802 — Decreto 407/2026</footer>
</main>

<script>
const fileInput = document.getElementById('fileInput');
const btn       = document.getElementById('btn');
const fnDiv     = document.getElementById('filename');
const status    = document.getElementById('status');
const dropZone  = document.getElementById('dropZone');
const form      = document.getElementById('form');

fileInput.addEventListener('change', () => {
  if (fileInput.files.length) {
    fnDiv.textContent = '✅ Archivo: ' + fileInput.files[0].name;
    btn.disabled = false;
  }
});

dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('dragover'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
dropZone.addEventListener('drop', e => {
  e.preventDefault(); dropZone.classList.remove('dragover');
  fileInput.files = e.dataTransfer.files;
  fileInput.dispatchEvent(new Event('change'));
});

form.addEventListener('submit', async e => {
  e.preventDefault();
  if (!fileInput.files.length) return;

  btn.disabled = true;
  status.className = 'status-load'; status.style.display = 'block';
  status.innerHTML = '<span class="spinner"></span> Procesando recibos...';

  try {
    const fd = new FormData();
    fd.append('txt_file', fileInput.files[0]);
    const res = await fetch('/convertir', { method: 'POST', body: fd });

    if (res.ok) {
      const blob = await res.blob();
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      const orig = fileInput.files[0].name.replace(/\.txt$/i,'');
      a.href = url; a.download = orig + '_407.pdf';
      a.click(); URL.revokeObjectURL(url);
      const n = res.headers.get('X-Recibos') || '?';
      status.className = 'status-ok';
      status.innerHTML = `✅ PDF generado con <strong>${n} recibo/s</strong>. Revisalo antes de subirlo a TuLegajo.`;
    } else {
      const txt = await res.text();
      status.className = 'status-err';
      status.innerHTML = '❌ Error: ' + txt;
    }
  } catch(err) {
    status.className = 'status-err';
    status.innerHTML = '❌ Error de conexión: ' + err;
  }
  btn.disabled = false;
});
</script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML)

@app.route('/convertir', methods=['POST'])
def convertir():
    if 'txt_file' not in request.files:
        return 'No se recibió archivo', 400
    f = request.files['txt_file']
    if not f.filename:
        return 'Archivo vacío', 400

    # Guardar TXT temporal
    tmp_txt = tempfile.NamedTemporaryFile(suffix='.txt', delete=False)
    f.save(tmp_txt.name)

    # Generar PDF
    tmp_pdf = tempfile.NamedTemporaryFile(suffix='.pdf', delete=False)
    tmp_pdf.close()

    try:
        # Importar el script de conversión
        sys.path.insert(0, os.path.dirname(__file__))
        import recibos_pdf
        import importlib; importlib.reload(recibos_pdf)

        recibos = recibos_pdf.parsear_txt(tmp_txt.name)
        if not recibos:
            return 'No se encontraron recibos en el archivo', 400
        recibos_pdf.generar_pdf(recibos, tmp_pdf.name)

        nombre_salida = f.filename.replace('.TXT','').replace('.txt','') + '_407.pdf'
        response = send_file(
            tmp_pdf.name,
            as_attachment=True,
            download_name=nombre_salida,
            mimetype='application/pdf'
        )
        response.headers['X-Recibos'] = str(len(recibos))
        return response

    except Exception as ex:
        return f'Error al procesar: {str(ex)}', 500
    finally:
        os.unlink(tmp_txt.name)

if __name__ == '__main__':
    print("=" * 55)
    print("  Conversor Recibos — Decreto 407/2026")
    print("  Abrí tu navegador en: http://localhost:5000")
    print("=" * 55)
    app.run(debug=False, port=5000)
